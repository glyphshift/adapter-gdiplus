# Glyphshift Adapter SDK

Source-only developer kit; not an end-user Runtime or GSP.
Contains Domain, SDK, Native ABI headers, native inspection, GSP packaging, and the reviewed retour patch.
Build glyphshift-adapter-tool for each target architecture to inspect locally built DLLs.
Use Cargo.lock and --locked. Native metadata inspection requires explicit digest approval.
No desktop/controller/target Runtime or archived UIA implementation is included.
Third-party retour source retains its BSD license; Glyphshift source uses the included LICENSE.
